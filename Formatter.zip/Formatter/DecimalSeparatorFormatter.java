package Formatter;

public class DecimalSeparatorFormatter {

}
